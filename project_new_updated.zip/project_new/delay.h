void delay_ms(int dlyMS);
void delay_us(int dlyUS);
void delay_s(int dlyS);

